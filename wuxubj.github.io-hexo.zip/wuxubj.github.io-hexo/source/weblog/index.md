---
title: 建站日志
date: 2016-07-18 15:29:58
---
### 建站日志
**2016-09-28：**备案获批 - 鄂ICP备16017973号 
**2016-08-20：**花了几天时间对``NexT.Pisces``主题进行了一些美化，参考博文[Hexo+nexT主题搭建个人博客](http://www.wuxubj.cn/2016/08/Hexo-nexT-build-personal-blog/)。至此网站外观已经定型，不打算再作任何改变。后期专注于写博文。
**2016-07-28：**将网站主题更换为[NexT.Pisces](https://github.com/iissnan/hexo-theme-next)
**2016-07-27：**添加本地搜索功能，不再使用swiftype搜索。
**2016-07-26：**网站托管到[腾讯云](https://www.qcloud.com/)，提高访问速度和稳定性。
**2016-07-18：**新建[建站日志](http://www.wuxubj.cn/weblog/)页面，并添加到侧栏链接。
**2016-07-17：**为网站添加301跳转，域名统一为[http://www.wuxubj.cn](http://www.wuxubj.cn/)，域名解析从腾讯云搬到DNSPod。
**2016-07-15：**[爱的纪念](http://www.wuxubj.cn/mylove/)页面用自定义音乐播放器替换网易云音乐外链播放器，解决部分歌曲因版权问题，无法生成外链。
**2016-07-08：**将网站中的图片等多媒体资源转移到[七牛云存储](http://www.qiniu.com/)。
**2016-07-02：**添加[爱的纪念](http://www.wuxubj.cn/mylove/)页面。
**2016-07-01：**为网站添加``CNZZ``站长统计，美化页脚显示。相关博文[Hexo+nexT页脚美化](http://www.wuxubj.cn/2016/07/06/footer-beautify-of-nexT/)。
**2016-05-28：**添加带``www``的域名解析，通过[http://wuxubj.cn](http://wuxubj.cn/)和[http://www.wuxubj.cn](http://www.wuxubj.cn/)均可访问本站。
**2016-05-24：**将网站同时部署到``GitHub``和``Coding``。
**2016-05-21：**发表我的[第一篇博文](http://www.wuxubj.cn/2016/05/Hexo搭建个人博客-初级篇/)，记录网站搭建过程中的关键问题。
**2016-05-11：**网站绑定个人域名[wuxubj.cn](http://wuxubj.cn/)，并正式上线。

**参考资料：**
1.&nbsp;&nbsp;[nexT官方文档](http://theme-next.iissnan.com/theme-settings.html)
2.&nbsp;&nbsp;[Issues of hexo-theme-next](https://github.com/iissnan/hexo-theme-next/issues)
3.&nbsp;&nbsp;[w3school](http://www.w3school.com.cn/)
4.&nbsp;&nbsp;[Git教程](https://git-scm.com/book/zh/v2/%E8%B5%B7%E6%AD%A5-%E5%AE%89%E8%A3%85-Git)
<center><div style="width:200px;height:200px;padding-bottom:30px;">![网站二维码](/images/wuxubj_mini.png)扫一扫，用手机访问本站</div></center>
<link rel="stylesheet" href="/css/mycss/underline.css">



