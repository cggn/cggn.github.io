---
title: 关于
date: 2016-05-21 18:19:45
heart: true
---
<blockquote class="blockquote-center">生活不止眼前的苟且，还有诗和远方的田野，
你赤手空拳来到人世间，为找到那片海不顾一切。</br><div class="demo" id="music"><div id="player3" class="aplayer"></div></div></blockquote>

---

>本站基于 [Hexo](http://hexo.io) 的 [NexT.Pisces](https://github.com/iissnan/hexo-theme-next) 主题搭建而成。非原创文章均带有[转]字标志且会在文中给出原文链接，其他文章均为原创。转载本站博文请保留必要署名，对于没有署名或是故意删除的，本人不再为其提供技术支持，敬请见谅...

* [建站日志](/weblog/)
* [博客搭建笔记](/2016/08/Hexo-nexT-build-personal-blog/)
* Email : [wuxubj@qq.com](mailto:wuxubj@qq.com)

---

<center><div style="width:200px;height:200px;padding-bottom:20px;">![网站二维码](/images/wuxubj_mini.png)扫一扫，用手机访问本站</div></center>
>&nbsp;<span class="dsrv_flag">最近访客</span><span id="dsrv_putaway" class="dsrv_flag hidden"><a href="javascript:void(0);" onclick="hideElement('ds-recent-visitors');showElement('dsrv_spread');hideElement('dsrv_putaway');hideElement('dsrv_putaway2');">收起</a></span><span id="dsrv_spread" class="dsrv_flag"><a href="javascript:void(0);" onclick="showElement('ds-recent-visitors');showElement('dsrv_putaway');showElement('dsrv_putaway2');hideElement('dsrv_spread')">展开</a></span>
<div class="ds-recent-visitors hidden" data-num-items="1000" data-avatar-size="24" id="ds-recent-visitors">加载中...</div><span id="dsrv_putaway2" class="dsrv_flag hidden"><a href="javascript:void(0);" onclick="hideElement('ds-recent-visitors');showElement('dsrv_spread');hideElement('dsrv_putaway');hideElement('dsrv_putaway2');">收起</a></span>

<link rel="stylesheet" href="/css/mycss/underline.css">
<link rel="stylesheet" href="http://jslibs.wuxubj.cn/APlayer/APlayer.min.css">
<link rel="stylesheet" href="/css/mycss/guestbook.css">
<script src="http://jslibs.wuxubj.cn/APlayer/APlayer.min.js"></script>
<script src="/js/myscript/guestbook.js"></script>