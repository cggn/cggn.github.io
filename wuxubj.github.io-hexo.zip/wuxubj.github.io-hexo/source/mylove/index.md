---
title: 爱的纪念
date: 2016-07-02 22:53:32
heart: true
---
>## 爱的纪念

<div id="headouter"><div id="headinner1">{% gp 1-3 %}<img id="mylove_tess" src="/images/lqw.jpg" width="120" height="120" onmouseover="imgStop('mylove_wuxubj');imgStop('mylove_tess')" onmouseout="imgStart('mylove_wuxubj');imgStart('mylove_tess')" />{% endgp %}</div><div id="headinner2">{% gp 1-3 %}<img id="mylove_wuxubj" src="/images/avatar.jpg" width="120" height="120" onmouseover="imgStop('mylove_wuxubj');imgStop('mylove_tess')" onmouseout="imgStart('mylove_wuxubj');imgStart('mylove_tess')" />{% endgp %}</div></div>
<blockquote class="blockquote-center" id="clear"><div id="lovelqw">李小二和雷宝宝牵手走过了：
    <span id="t_d">00</span>天<span id="t_h">00</span>时<span id="t_m">00</span>分<span id="t_s">00</span>秒
<span id="loveYear">今天是第<span id="t_month">00</span>个月，第<span id="t_year">00</span>年 ！</span></div></blockquote><form><!--当点击相应按钮，执行相应操作，为按钮添加相应事件--><input type="button" id="bthidden" onclick="hideElement('music');showElement('btshow');hideElement('bthidden')" value="隐藏音乐" > <input type="button" id="btshow" class="hidden" onclick="showElement('music');showElement('bthidden');hideElement('btshow')" value="显示音乐" ></form><div class="demo" id="music"><div id="player3" class="aplayer"></div></div>
<span>[小游戏](http://thirdparty.wuxubj.cn/fruitslice/index.html)</span>
<a title="小high一下~" rel="alternate" class="mw-harlem_shake_slow wobble shake" href="javascript:shake()">High起来</a>
### 照片墙
<div class="imageborder">[![photowall](http://thirdparty.wuxubj.cn/photowall/images/0.jpeg)](/thirdparty/photowall/)</div>
<link rel="stylesheet" href="/css/mycss/underline.css">
<link rel="stylesheet" href="http://jslibs.wuxubj.cn/APlayer/APlayer.min.css">
<link rel="stylesheet" href="/css/mycss/mylove.css">
<script src="http://jslibs.wuxubj.cn/APlayer/APlayer.min.js"></script>
<script src="/js/myscript/mylove.js"></script>

