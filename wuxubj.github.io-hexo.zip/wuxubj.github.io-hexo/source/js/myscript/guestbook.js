        var ap3 = new APlayer({
            element: document.getElementById('player3'),
            narrow: false,
            autoplay: false,
            showlrc: false,
            music: {
                title: '生活不止眼前的苟且',
                author: '许巍',
                url: 'http://media.wuxubj.cn/%E7%94%9F%E6%B4%BB%E4%B8%8D%E6%AD%A2%E7%9C%BC%E5%89%8D%E7%9A%84%E8%8B%9F%E4%B8%94.mp3',
                pic: 'http://media.wuxubj.cn/%E7%94%9F%E6%B4%BB%E4%B8%8D%E6%AD%A2%E7%9C%BC%E5%89%8D%E7%9A%84%E8%8B%9F%E4%B8%94.jpg'
            }
        });
        ap3.init();